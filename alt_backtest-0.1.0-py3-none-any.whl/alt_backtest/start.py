from .backtest import backtest, print_metrix, get_plot
from .strategy import Strategy


def run(strategy: Strategy, start_cash, data__path, start_date, end_date, format_date):
    cerebro, result = backtest(strategy, start_cash, data__path, start_date, end_date, format_date)
    print_metrix(cerebro, result)
    get_plot(cerebro)
