from enum import Enum


class Price(Enum):
    close = 1
    open = 2
    low = 3
    high = 4
