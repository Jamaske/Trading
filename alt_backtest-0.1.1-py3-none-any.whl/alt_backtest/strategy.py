import backtrader as bt
import wrapt

from .position import Position
from .price import Price


class Strategy(bt.Strategy):

    def in_position(self) -> bool:
        return self.position_status == Position.long or self.position_status == Position.short

    def status_set_wrapper(self, wrapped, instance, args, kwargs):
        prev_status = getattr(instance, "status", None)
        result = wrapped(*args, **kwargs)
        new_status = getattr(instance, "status", None)

        if prev_status != new_status:
            if bt.Order.Status[new_status] == "Margin":
                self.margin_call()
            elif bt.Order.Status[new_status] == "Rejected":
                self.order_rejected_call()

        return result

    def __init__(self):
        self.position_status = Position.none
        wrapt.wrap_function_wrapper(bt.Order, "__setattr__", self.status_set_wrapper)

    def margin_call(self):
        raise NotImplementedError("Margin call not processed")

    def order_rejected_call(self):
        raise NotImplementedError("Order rejected not processed")

    def next(self):
        pass
    def get_price(self, price_type: Price = Price.close):
        if price_type==Price.high:
            return self.data.high[0]
        elif price_type==Price.open:
            return self.data.open[0]
        elif price_type==Price.low:
            return self.data.low[0]
        elif price_type==Price.close:
            return self.data.close[0]
        else:
            raise Exception("Такого типа цены нет:(")

    def send_market_order_buy(self, size = 1):
        return self.buy(size=size)
    def send_market_order_sell(self, size = 1):
        return self.sell(size=size)


    def send_limit_order_buy(self, price:float, size: int):
        return self.buy(price=price, size=size, exectype=bt.Order.Limit)
    def send_limit_order_sell(self, price:float, size: int):
        return self.sell(price=price, size=size, exectype=bt.Order.Limit)

    def send_stop_order_buy(self, price:float, size: int):
       return self.buy(price=price, size=size, exectype=bt.Order.Stop)
    def send_stop_order_sell(self, price:float, size: int):
        return self.sell(price=price, size=size, exectype=bt.Order.Stop)

    def send_stop_limit_order_buy(self, stop_price, limit_price, size):
        return self.buy(price=stop_price, size=size, exectype=bt.Order.StopLimit, plimit=limit_price)
    def send_stop_limit_order_sell(self, stop_price, limit_price, size):
        return self.sell(price=stop_price, size=size, exectype=bt.Order.StopLimit, plimit=limit_price)

    def get_order_status(self, order: bt.Order) -> str:
        return bt.Order.Status[order.status]

    def cancel_order(self, order):
        self.cancel(order)

