import pandas as pd
import backtrader as bt
from backtrader import Cerebro


from .strategy import Strategy


def backtest(strategy: Strategy, start_cash, data__path, start_date, end_date, format_date) -> (Cerebro, ):
    data = bt.feeds.GenericCSVData(dataname=data__path, fromdate=pd.Timestamp(start_date), todate=pd.Timestamp(end_date), dtformat=format_date)

    cerebro = bt.Cerebro()
    cerebro.broker.set_cash(start_cash)

    cerebro.addstrategy(strategy)

    cerebro.adddata(data)

    cerebro.addanalyzer(bt.analyzers.SharpeRatio, _name='sharpe', timeframe=bt.TimeFrame.Days)

    results = cerebro.run()

    return cerebro, results




def print_metrix(cerebro:Cerebro, results):
    sharpe_ratio = results[0].analyzers.getbyname('sharpe').get_analysis()
    initial_balance = cerebro.broker.startingcash
    final_balance = cerebro.broker.getvalue()
    profit_percent = ((final_balance - initial_balance) / initial_balance) * 100

    print('Итоговый баланс:', cerebro.broker.getvalue())
    print('Profit Persent за все время:', profit_percent)
    print('Sharpe Ratio:', sharpe_ratio['sharperatio'])

def get_plot(cerebro: Cerebro):
    cerebro.plot()