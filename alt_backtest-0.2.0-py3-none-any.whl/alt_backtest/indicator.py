import backtrader as bt

from .price import Price


class Indicator(bt.Indicator):
    lines = ('custom_indicator',)

    @staticmethod
    def is_ready() -> bool:
        return False

    def __init__(self):
        super(Indicator, self).__init__()
        self.custom_value = 0

    def next(self):
        self.lines.custom_indicator[0] = self.custom_value

    def get_price(self, price_type: Price = Price.close):
        if price_type == Price.high:
            return self.data.high[0]
        elif price_type == Price.open:
            return self.data.open[0]
        elif price_type == Price.low:
            return self.data.low[0]
        elif price_type == Price.close:
            return self.data.close[0]
        else:
            raise Exception("Такого типа цены нет:(")
