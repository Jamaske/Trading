from enum import Enum


class Position(Enum):
    long = 1
    short = 2
    none = 3